#ifndef __TASKIRQ_H_
#define __TASKIRQ_H_

void Task_EXTI9_5_IRQHandler(void);
void Task_EXTI15_10_IRQHandler(void);
void Task_USART1_IRQHandler(void);
void Task_USART2_IRQHandler(void);

#endif
