#ifndef __TASK_DEPTHCONTROL_H_
#define __TASK_DEPTHCONTROL_H_

#define pH_K -5.8887
#define pH_b 21.677

#include "task_conf.h"
#include "usercode.h"
#include "config.h"


float Get_pH_Value(tagADC_T *_tADC);



#endif
