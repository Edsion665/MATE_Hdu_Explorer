#ifndef __TASKUSERINIT_H_
#define __TASKUSERINIT_H_

void Task_UserInit(void);

#endif
