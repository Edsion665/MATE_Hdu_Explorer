#include "task_conf.h"
#include "usercode.h"
#include "config.h"

extern PWMInfo_T PWMInfo;

/* 深度控制函数，需要当前深度和期望深度 */
void task_DepthControl_Process(float Curr,float Exp)
{
    PIDOut = 0.0;
    float error = Exp - Curr;
    
	// printf("CurrDepth :%f\n\r",Curr);
    // printf("ExpDepth :%f\n\r",Exp);
    // printf("PIDOUT :%f\n\r",PIDOut);
    //printf("Error :%f\n\r",error);
    //增量式PID直接赋值，用在定深控制效果良好
    if(DepthFlag & 0x01)  //开启定深模式
    {
        // PIDOut = get_pid(&Depth_PID,error);
        PIDOut += -Algo_PID_Calculate(&DepthPID,Curr,Exp);//采用增量式 PID限幅
        if(PIDOut >= MAX_PIDOUT)
        {
            PIDOut = MAX_PIDOUT;
        }
        else if(PIDOut <= MIN_PIDOUT)
        {
            PIDOut = MIN_PIDOUT;
        }
    }
    else
        PIDOut = 0;
	if(x_y_z_pitch & 0x08)
            PIDOut = 130;
	if(x_y_z_pitch & 0x04)
            PIDOut = -130;
    //规避死区 正转1525 反转1465
    if(PIDOut == 0)
        PWMInfo.PWMout[h_wheel1_speed] = PIDOut + STOP_PWM_VALUE;
    if(PIDOut > 0)
        PWMInfo.PWMout[h_wheel1_speed] = PIDOut + STOP_PWM_VALUE_F;
    if(PIDOut < 0)
        PWMInfo.PWMout[h_wheel1_speed] = PIDOut + STOP_PWM_VALUE_B;
   
    //限幅
    if(PWMInfo.PWMout[h_wheel1_speed] < 1370)  PWMInfo.PWMout[h_wheel1_speed] = 1370;
    if(PWMInfo.PWMout[h_wheel1_speed] > 1670)  PWMInfo.PWMout[h_wheel1_speed] = 1670;
    //四个电机输出信号大小配一致
    PWMInfo.PWMout[h_wheel2_speed] = PWMInfo.PWMout[h_wheel1_speed];
    PWMInfo.PWMout[h_wheel3_speed] = PWMInfo.PWMout[h_wheel1_speed];
    PWMInfo.PWMout[h_wheel4_speed] = PWMInfo.PWMout[h_wheel1_speed];
    
    // Task_Balance_Process();
    
    Task_Thruster_SpeedSet(h_wheel1_speed,PWMInfo.PWMout[h_wheel1_speed]);
    Task_Thruster_SpeedSet(h_wheel2_speed,PWMInfo.PWMout[h_wheel2_speed]);
    Task_Thruster_SpeedSet(h_wheel3_speed,PWMInfo.PWMout[h_wheel3_speed]);
    Task_Thruster_SpeedSet(h_wheel4_speed,PWMInfo.PWMout[h_wheel4_speed]);
}
