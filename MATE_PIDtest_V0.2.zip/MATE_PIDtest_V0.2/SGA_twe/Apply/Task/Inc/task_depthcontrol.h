#ifndef __TASK_PH_OUTCOME_H_
#define __TASK_PH_OUTCOME_H_

void task_DepthControl_Process(float Curr,float Exp);
#define MAX_PIDOUT 115
#define MIN_PIDOUT -115

#endif
