#ifndef __TASK_HANDLEMODE_H_
#define __TASK_HANDLEMODE_H_

void Task_HandleMode_Process(HandleModeInfo HMInfo);
void HandleMode_data_handle(void);


#define YAW_RIGHT 1 
#define YAW_LEFT  2  
#endif
