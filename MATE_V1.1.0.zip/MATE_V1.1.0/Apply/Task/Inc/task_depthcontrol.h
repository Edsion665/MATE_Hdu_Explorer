#ifndef __TASK_PH_OUTCOME_H_
#define __TASK_PH_OUTCOME_H_

void task_DepthControl_Process(float Curr,float Exp);

#endif
